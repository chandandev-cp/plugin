<?php
get_header();
?>
<!-- plus image start -->
	<section class="plus_img_sec">
		<div class="container">
			<div class="plus_img_innr">
				<div class="plus_img_flx">
					<div class="plus_img_lft">
						<div class="plus_img_lft_pic">
                        <?php if ( has_post_thumbnail() ):?>
							<?php the_post_thumbnail(); ?>
                        <?php endif; ?>
						</div>
					</div>
					<div class="plus_img_rght">
						<div class="plus_img_rght_flx">
                            <?php
                            if(have_rows('property_all_images')){
                                while(have_rows('property_all_images')){
                                    the_row();
                                    ?>
                                <div class="plus_img_rght_img">
                                    <div class="plus_img_rght_pic">
                                        <img src="<?php the_sub_field('image');?>" alt="img">
                                    </div>
							    </div>
                                    <?php
                                }
                            }
                            ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- plus image end -->

    <!-- prpt category part start -->
    
	<section class="prpt_ctg_sec ech_vw_ctg_sec">
	<div class="container">        
			<div class="prpt_ctg_innr">
			<?php
		// Start the loop
		if ( have_posts() ) :
			while ( have_posts() ) : the_post();

			// Fetch the custom fields meta data
			$property_custom_fields = get_post_meta( get_the_ID(), '_property_custom_fields', true );
			$custom_field1 = !empty( $property_custom_fields[0] ) ? esc_html( $property_custom_fields[0] ) : '';
			$custom_field2 = !empty( $property_custom_fields[1] ) ? esc_html( $property_custom_fields[1] ) : '';
			$custom_field3 = !empty( $property_custom_fields[2] ) ? esc_html( $property_custom_fields[2] ) : '';
			$custom_field4 = !empty( $property_custom_fields[3] ) ? esc_html( $property_custom_fields[3] ) : '';
			$custom_field5 = !empty( $property_custom_fields[4] ) ? esc_html( $property_custom_fields[4] ) : '';
			$custom_field6 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[5] ) : '';
			$custom_field7 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[6] ) : '';
			$custom_field8 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[7] ) : '';
			$custom_field9 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[8] ) : '';
			$custom_field10 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[9] ) : '';
			$custom_field11 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[10] ) : '';
			$custom_field12 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[11] ) : '';
			$custom_field13= !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[12] ) : '';
			$custom_field14 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[13] ) : '';
			$custom_field15 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[14] ) : '';

			?>
				<h4><?php echo the_title();?> <span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span></h4>
				<h6 class="ctg_sm"><?php echo the_content();?></h6>
				
                <ul>
					<li><span></span><?php echo esc_html( $custom_field1); ?></li>
					<li><span></span> <?php echo esc_html( $custom_field2); ?></li>
				</ul>
				<div class="prpt_ctg_flx">
					<div class="apt_itm_nmbrs">
						<span>
							<img src="<?php echo bloginfo('template_url');?>/assets/images/bd.png" alt="img">
							<?php echo esc_html( $custom_field3); ?>
						</span>
						<span>
							<img src="<?php echo bloginfo('template_url');?>/assets/images/bth.png" alt="img">
							<?php echo esc_html( $custom_field4); ?>
						</span>
						<span>
							<img src="<?php echo bloginfo('template_url');?>/assets/images/msq.png" alt="img">
							<?php echo esc_html( $custom_field5); ?>
						</span>
					</div>
					<div class="rqst_info_flx">
						<div class="rqst_info_lft">
							<h3><?php echo the_excerpt(); ?></h3>
						</div>
						<div class="rqst_info_rght">
							<a href="#frm_rqst" class="cmn_btn"><?php echo esc_html( $custom_field6); ?></a>
						</div>
					</div>
				</div>
				<div class="prpt_ctg_bsc">
					<div class="prpt_ctg_bsc_top">
						<div class="cmn_hdr">
							<h6>Basics</h6>
						</div>
						<span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span>
					</div>
					<div class="prpt_ctg_bsc_bxs">
						<div class="prpt_ctg_bx <?php the_field('sentryclass_info');?>">
							<div class="prpt_ctg_bx_img">
								<img src="<?php echo bloginfo('template_url');?>/assets/images/bth.png" alt="img">
							</div>
							<div class="prpt_ctg_bx_txt">
								<span class="deep"><?php echo esc_html( $custom_field7); ?></span>
								<span class="thin"><?php echo esc_html( $custom_field8); ?></span>
								<span class="thin"><?php echo esc_html( $custom_field15); ?></span>
							</div>
							<!-- <span>
								<img src="./images/bth.png" alt="img">
								1 Baths
							</span>
							<span>
								<img src="./images/msq.png" alt="img">
								66.32 m²
							</span> -->
						</div>
						<div class="prpt_ctg_bx">
							<div class="prpt_ctg_bx_img">
								<img src="<?php echo bloginfo('template_url');?>/assets/images/tpbk.png" alt="img">
							</div>
							<div class="prpt_ctg_bx_txt">
								<span class="deep"><?php echo esc_html( $custom_field9); ?></span>
								<span class="thin"><?php echo esc_html( $custom_field10); ?></span>
							</div>
							<!-- <span>
								<img src="./images/bth.png" alt="img">
								1 Baths
							</span>
							<span>
								<img src="./images/msq.png" alt="img">
								66.32 m²
							</span> -->
						</div>
						<div class="prpt_ctg_bx">
							<div class="prpt_ctg_bx_img">
								<img src="<?php echo bloginfo('template_url');?>/assets/images/bd.png" alt="img">
							</div>
							<div class="prpt_ctg_bx_txt">
								<span class="deep"><?php echo esc_html( $custom_field11); ?></span>
								<span class="thin"><?php echo esc_html( $custom_field12); ?></span>
							</div>
							<!-- <span>
								<img src="./images/bth.png" alt="img">
								1 Baths
							</span>
							<span>
								<img src="./images/msq.png" alt="img">
								66.32 m²
							</span> -->
						</div>
						<div class="prpt_ctg_bx">
							<!-- <div class="prpt_ctg_bx_img">
								<img src="<?php //echo bloginfo('template_url');?>/assets/images/bth.png" alt="img">
							</div> -->
							<div class="prpt_ctg_bx_txt">
								<span class="deep"><?php echo esc_html( $custom_field13); ?></span>
								<span class="thin"><?php echo esc_html( $custom_field14); ?></span>
							</div>
							<!-- <span>
								<img src="./images/bth.png" alt="img">
								1 Baths
							</span>
							<span>
								<img src="./images/msq.png" alt="img">
								66.32 m²
							</span> -->
						</div>
					</div>
				</div>
				<?php
				 endwhile;
				endif;
				?>
			</div>
           
		</div>
	</section>

	<!-- prpt category part end -->

	<!-- echo view description start -->
	<section class="prpt_dsc_sec ech_vw_sec">
		<div class="container">
			<div class="prpt_dsc_flx">
				<div class="prpt_dsc_lft">
					<div class="prpt_dsc_lft_top">
						<div class="cmn_hdr">
							<h6><?php the_field('description_heading');?></h6>
						</div>
						<span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span>
					</div>
					<div class="prpt_dsc_lft_txt">
						<div class="cmn_hdr">
							<?php the_field('description_sec_content');?>
						</div>
					</div>
					<div class="amnt_ftr_sec">
						<div class="amnt_ftr_otr">
							<div class="amnt_ftr_innr">
								<div class="prpt_dsc_lft_top">
									<div class="cmn_hdr">
										<h6><?php the_field('amenities_features_heading');?></h6>
									</div>
									<span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span>
								</div>
								<div class="amnt_ftr_pnts">
									<?php 
									if(have_rows('amenities_features_details')){
										while(have_rows('amenities_features_details')){
											the_row();
											?>
									<div class="amnt_ftr_pntbx">
										<div class="amnt_ftr_pntbx_img">
											<img src="<?php the_sub_field('image');?>" alt="img">
										</div>
										<div class="amnt_ftr_pntbx_txt">
											<h6><?php the_sub_field('heading');?></h6>
										</div>
									</div>
											<?php
										}
									}
									?>
									
								</div>
							</div>
						</div>
					</div>
					<div class="prpt_lcn_sec">
						<div class="prpt_lcn_ottr">
							<div class="prpt_dsc_lft_top">
								<div class="cmn_hdr">
									<h6><?php the_field('location_heading');?></h6>
								</div>
								<span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span>
							</div>
							<!-- <iframe class="prpt_lcn_frame"
									src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3091.581263054765!2d-76.81875912351295!3d39.20696252837832!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7e072f29dc197%3A0xd94f066349c1372a!2sGemStar%20Property%20Management!5e0!3m2!1sen!2sin!4v1726823398934!5m2!1sen!2sin"
									width="100%" style="border:0;" allowfullscreen="" loading="lazy"
									referrerpolicy="no-referrer-when-downgrade"></iframe> -->
							<div class="prpt_lcn_frame">
								<img src="<?php the_field('location_sec_image');?>" alt="img">
								<!-- <span class="mp_mrk">
									<i class="fas fa-map-marker-alt"></i>
								</span> -->
							</div>
						</div>
					</div>
				</div>
				<div class="prpt_dsc_rght" id="frm_rqst">
					<div class="gt_tch_rght">
						<div class="gt_tch_rght_txt">
							<div class="cmn_hdr wht">
								<h6><?php the_field('agent_about_heading');?></h6>
							</div>

						</div>
						<div class="gt_tch_rght_usrttl">
							<!-- <div class="gt_tch_rght_user">
								<i class="fas fa-user"></i>
							</div> -->
							<div class="gt_tch_rght_usrtxt">
							<?php the_field('agent_name_heading');?>
							</div>
						</div>
						<div class="gt_tch_rght_frm" >
							<?php echo do_shortcode('[contact-form-7 id="3aaca09" title="property request info form"]');?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- echo view description end -->
	 <!-- new journey start -->

	 <section class="new_jour cmn_pdding" style="background: url(<?php echo bloginfo('template_url');?>/assets/images/get_start_im.png) no-repeat;
background-size: 100% 100%;
width: 100%;
height: 100%;">
        <div class="container">
            <div class="new_innr cmn_hdr wht">
                <div class="new_jour_img">
                    <img src="<?php the_field('new_journey_image',6);?>" />
                </div>
                <h2><?php the_field('new_journey_heading',6);?></h2>
                <p><?php the_field('new_journey_content',6);?></p>
                <div class="rd_mr">
                <?php $nwjrny_getstarted_button = get_field('new_journey_getstarted_button',6);?>
                    <a href="<?php echo $nwjrny_getstarted_button['url'];?>" class="rd_mr_btn"><?php echo $nwjrny_getstarted_button['title'];?></a>
                </div>
            </div>
        </div>
    </section>
	<!-- new journey end -->
<?php
get_footer();
?>
<!-- plus image js start -->
<script>
		document.addEventListener("DOMContentLoaded", function () {
			var plusImgLft = document.querySelector(".plus_img_lft");
			var plusImgRght = document.querySelector(".plus_img_rght");
			var plusImgRghtInr = document.querySelectorAll(".plus_img_rght_img"); // Select all instances
			var plusRightImg = document.querySelector(".plus_img_rght_flx .plus_img_rght_img:last-child");

			if (plusRightImg) {
				plusRightImg.addEventListener("click", plRi);
			}

			// This function expands the images
			function plRi(event) {
				event.stopPropagation(); // Prevents this click from bubbling up to the document
				if (plusImgLft && plusImgRght && plusImgRghtInr.length > 0) {
					// Expand the images
					plusImgLft.style.cssText = "width: 60%; margin-inline: auto;";
					plusImgRght.style.cssText = "width: 60%; margin-inline: auto;";

					// Hide the +30 pseudo element
					plusRightImg.classList.add("hide-pseudo");

					plusImgRghtInr.forEach(function (element) {
						element.style.cssText = "width: 100%; margin-inline: auto;";
					});

					// Attach the listener for clicking outside
					document.addEventListener("click", handleDocumentClick);
				}
			}

			// This function resets the images to the original state
			function resetImages() {
				// Reset the styles
				plusImgLft.style.cssText = "";
				plusImgRght.style.cssText = "";
				plusImgRghtInr.forEach(function (element) {
					element.style.cssText = "";
				});

				// Show the +30 pseudo element again
				plusRightImg.classList.remove("hide-pseudo");

				// Remove the click listener after resetting
				document.removeEventListener("click", handleDocumentClick);
			}

			// This function handles clicks outside the images
			function handleDocumentClick(event) {
				// If the click is not on the last image, reset the images
				if (!plusRightImg.contains(event.target)) {
					resetImages();
				}
			}
		});
	</script>
	<!-- plus image js end -->
		<script type="text/javascript">
		document.addEventListener('DOMContentLoaded', function() {
			// Get the page title
			var pageTitle = document.title;

			// Find the hidden field in the Contact Form 7 form
			var hiddenField = document.querySelector('input[name="txt-1"]');

			if (hiddenField) {
				// Set the page title as the value of the hidden field
				hiddenField.value = pageTitle;
			}
		});
</script>
