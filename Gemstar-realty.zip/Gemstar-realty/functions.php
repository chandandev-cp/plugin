 <?php
function custom_css()
{
    wp_enqueue_style('font_awesome_css',get_template_directory_uri().'/assets/css/font-awesome.css',array(), 1.0, 'all');
    wp_enqueue_style('line_css',"https://unicons.iconscout.com/release/v4.0.0/css/line.css",array(),1.0,'all');
    wp_enqueue_style('solid_css',"https://unicons.iconscout.com/release/v4.0.0/css/solid.css",array(),1.0,'all');
    wp_enqueue_style('thinline_css',"https://unicons.iconscout.com/release/v4.0.0/css/thinline.css",array(),1.0,'all');
    wp_enqueue_style('bootstrap_min_css',get_template_directory_uri().'/assets/css/bootstrap.min.css',array(), 1.0, 'all');
    wp_enqueue_style('animate_css',get_template_directory_uri().'/assets/css/animate.css',array(), 1.0, 'all');
    wp_enqueue_style('animate_min_css',"https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css",array(),1.0,'all');
    wp_enqueue_style('jquery_fancybox_css',get_template_directory_uri().'/assets/css/jquery.fancybox.css',array(), 1.0, 'all');
    wp_enqueue_style('easy_responsive_tabs_css',get_template_directory_uri().'/assets/css/easy-responsive-tabs.css',array(), 1.0, 'all');
    wp_enqueue_style('swiper_css',get_template_directory_uri().'/assets/css/swiper.css',array(), 1.0, 'all');
    wp_enqueue_style('custom_css',get_template_directory_uri().'/assets/css/custom.css',array(), 1.0, 'all');
    wp_enqueue_style('responsive_css',get_template_directory_uri().'/assets/css/responsive.css',array(), 1.0, 'all');
    wp_enqueue_style('aos_css',get_template_directory_uri().'/assets/css/aos.css',array(), 1.0, 'all');
}
add_action('wp_enqueue_scripts', 'custom_css');
function custom_js()
{
    wp_enqueue_script('jquery_min_js', get_template_directory_uri().'/assets/js/jquery.min.js', array(), '', 'true');
    wp_enqueue_script('bootstrap_min_js',get_template_directory_uri().'/assets/js/bootstrap.min.js', array(), '', 'true' );
    wp_enqueue_script('wow_min_js',get_template_directory_uri().'/assets/js/wow.min.js', array(), '', 'true' );
    wp_enqueue_script('font_awesome_all_min_js',get_template_directory_uri().'/assets/js/font-awesome-all.min.js', array(), '', 'true' );
    wp_enqueue_script('bundle_js', 'https://unicons.iconscout.com/release/v4.0.0/script/monochrome/bundle.js', array(), '', 'true');
    wp_enqueue_script('jquery_fancybox_pack_js',get_template_directory_uri().'/assets/js/jquery.fancybox.pack.js', array(), '', 'true' );
    wp_enqueue_script('easy_responsive_tabs_js',get_template_directory_uri().'/assets/js/easy-responsive-tabs.js', array(), '', 'true' );
    wp_enqueue_script('swiper_js',get_template_directory_uri().'/assets/js/swiper.js', array(), '', 'true' );
    wp_enqueue_script('aos_js',get_template_directory_uri().'/assets/js/aos.js', array(), '', 'true' );
    wp_enqueue_script('custom_js',get_template_directory_uri().'/assets/js/custom.js', array(), '', 'true' );
}
add_action('wp_enqueue_scripts', 'custom_js');
/**Header Logo */
add_theme_support('custom-header');
add_theme_support('post-thumbnails');
function theme_setup()
   {
      add_theme_support('custom-logo');
      add_image_size('mytheme-logo', 160, 90);
      add_theme_support(
         'custom-logo', array(
            'size' => 'mytheme-logo'
         )
      );
   }
add_action('after_setup_theme', 'theme_setup');
/**Custom Navbar Menu */
register_nav_menus(
    array(
        'header-menu'   =>  'Header Menu',
        'footer-menu'   =>  'Footer Menu',
        'social-media'  =>  'Social Media'
    )
);
/* Bootstrap 5 navwalker */
class bootstrap_5_wp_nav_menu_walker extends Walker_Nav_menu
{
private $current_item;
private $dropdown_menu_alignment_values = [
   'dropdown-menu-start',
   'dropdown-menu-end',
   'dropdown-menu-sm-start',
   'dropdown-menu-sm-end',
   'dropdown-menu-md-start',
   'dropdown-menu-md-end',
   'dropdown-menu-lg-start',
   'dropdown-menu-lg-end',
   'dropdown-menu-xl-start',
   'dropdown-menu-xl-end',
   'dropdown-menu-xxl-start',
   'dropdown-menu-xxl-end'
];
function start_lvl(&$output, $depth = 0, $args = null)
{
   $dropdown_menu_class[] = '';
   foreach($this->current_item->classes as $class) {
      if(in_array($class, $this->dropdown_menu_alignment_values)) {
      $dropdown_menu_class[] = $class;
      }
   }
   $indent = str_repeat("\t", $depth);
   $submenu = ($depth > 0) ? ' sub-menu' : '';
   $output .= "\n$indent<ul class=\"dropdown-menu$submenu " . esc_attr(implode(" ",$dropdown_menu_class)) . " depth_$depth\">\n";
}
function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
{
   $this->current_item = $item;
   $indent = ($depth) ? str_repeat("\t", $depth) : '';
   $li_attributes = '';
   $class_names = $value = '';
   $classes = empty($item->classes) ? array() : (array) $item->classes;
   $classes[] = ($args->walker->has_children) ? 'dropdown' : '';
   $classes[] = 'nav-item';
   $classes[] = 'nav-item-' . $item->ID;
   if ($depth && $args->walker->has_children) {
      $classes[] = 'dropdown-menu dropdown-menu-end';
   }
   $class_names =  join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
   $class_names = ' class="' . esc_attr($class_names) . '"';
   $id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args);
   $id = strlen($id) ? ' id="' . esc_attr($id) . '"' : '';
   $output .= $indent . '<li ' . $id . $value . $class_names . $li_attributes . '>';
   $attributes = !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
   $attributes .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
   $attributes .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
   $attributes .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';
   $active_class = ($item->current || $item->current_item_ancestor || in_array("current_page_parent", $item->classes, true) || in_array("current-post-ancestor", $item->classes, true)) ? 'active' : '';
   $nav_link_class = ( $depth > 0 ) ? 'dropdown-item ' : 'nav-link ';
   $attributes .= ( $args->walker->has_children ) ? ' class="'. $nav_link_class . $active_class . ' dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"' : ' class="'. $nav_link_class . $active_class . '"';
   $item_output = $args->before;
   $item_output .= '<a' . $attributes . '>';
   $item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
   $item_output .= '</a>';
   $item_output .= $args->after;
   $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
}
}
// Add custom classes to menu items based on the theme location
function add_custom_class_to_menu_items($classes, $item, $args) {
    if ($args->theme_location === 'header-menu') {
        $classes[] = 'nav-item';  // Header menu <li> class
    } elseif ($args->theme_location === 'footer-menu') {
        $classes[] = 'cmn_ftr_list_itm';  // Footer menu <li> class
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'add_custom_class_to_menu_items', 10, 3);
/**Register Fields at settings area*/
add_action('admin_init', 'register_fields');
function register_fields()
{
    register_setting('general', 'explore_button', 'esc_attr');
    add_settings_field('explore_button', '<label for="explore_button">'
    .__('Explore button' , 'explore_button' ).'</label>' , 'explore_button', 'general');

    register_setting('general', 'explore_text', 'esc_attr');
    add_settings_field('explore_text', '<label for="explore_text">'
    .__('Explore Text' , 'explore_text' ).'</label>' , 'explore_text', 'general');

    register_setting('general', 'footer_cntnt', 'esc_attr');
    add_settings_field('footer_cntnt', '<label for="footer_cntnt">'
    .__('Footer Content' , 'footer_cntnt' ).'</label>' , 'footer_cntnt', 'general');

    register_setting('general', 'call', 'esc_attr');
    add_settings_field('call', '<label for="call">'
    .__('Call' , 'call' ).'</label>' , 'call', 'general');

    register_setting('general', 'email', 'esc_attr');
    add_settings_field('email', '<label for="mail">'
    .__('Email' , 'email' ).'</label>' , 'email', 'general');

    register_setting('general', 'facebook', 'esc_attr');
    add_settings_field('facebook', '<label for="mail">'
    .__('Facebook' , 'facebook' ).'</label>' , 'facebook', 'general');

    register_setting('general', 'linkedin', 'esc_attr');
    add_settings_field('linkedin', '<label for="mail">'
    .__('Linkedin' , 'linkedin' ).'</label>' , 'linkedin', 'general');

    register_setting('general', 'twitter', 'esc_attr');
    add_settings_field('twitter', '<label for="mail">'
    .__('Twitter' , 'twitter' ).'</label>' , 'twitter', 'general');

    register_setting('general', 'term_condtn', 'esc_attr');
    add_settings_field('term_condtn', '<label for="mail">'
    .__('Terms and condition' , 'term_condtn' ).'</label>' , 'term_condtn', 'general');

    register_setting('general', 'privacy', 'esc_attr');
    add_settings_field('privacy', '<label for="mail">'
    .__('Privacy policy' , 'privacy' ).'</label>' , 'privacy', 'general');
}
function explore_button()
{
    $value = get_option( 'explore_button', '' );
    echo '<input type="text" id="explore_button" name="explore_button"
    class="regular-text" value="' . $value . '" />';
}
function explore_text()
{
    $value = get_option( 'explore_text', '' );
    echo '<input type="text" id="explore_text" name="explore_text"
    class="regular-text" value="' . $value . '" />';
}
function footer_cntnt()
{
    $value = get_option( 'footer_cntnt', '' );
    echo '<input type="text" id="footer_cntnt" name="footer_cntnt"
    class="regular-text" value="' . $value . '" />';
}
function call()
{
    $value = get_option( 'call', '' );
    echo '<input type="text" id="call" name="call"
    class="regular-text" value="' . $value . '" />';
}
function email()
{
    $value = get_option( 'email', '' );
    echo '<input type="text" id="email" name="email"
    class="regular-text" value="' . $value . '" />';
}
function facebook()
{
    $value = get_option( 'facebook', '' );
    echo '<input type="text" id="facebook" name="facebook"
    class="regular-text" value="' . $value . '" />';
}
function linkedin()
{
    $value = get_option( 'linkedin', '' );
    echo '<input type="text" id="linkedin" name="linkedin"
    class="regular-text" value="' . $value . '" />';
}
function twitter()
{
    $value = get_option( 'twitter', '' );
    echo '<input type="text" id="twitter" name="twitter"
    class="regular-text" value="' . $value . '" />';
}
function term_condtn()
{
    $value = get_option( 'term_condtn', '' );
    echo '<input type="text" id="term_condtn" name="term_condtn"
    class="regular-text" value="' . $value . '" />';
}
function privacy()
{
    $value = get_option( 'privacy', '' );
    echo '<input type="text" id="privacy" name="privacy"
    class="regular-text" value="' . $value . '" />';
}
/**Post Type for property */
function property_init() {
    // set up product labels
    $labels = array(
        'name' => 'Properties',
        'singular_name' => 'Properties',
        'add_new' => 'Add New Properties',
        'add_new_item' => 'Add New Properties',
        'edit_item' => 'Edit Properties',
        'new_item' => 'New Properties',
        'all_items' => 'All Properties',
        'view_item' => 'View Properties',
        'search_items' => 'Search Properties',
        'not_found' =>  'No Properties Found',
        'not_found_in_trash' => 'No Properties found in Trash',
        'parent_item_colon' => '',
        'menu_name' => 'Properties',
    );
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'property'),
        'query_var' => true,
        'menu_icon' => 'dashicons-admin-multisite',
        'supports' => array(
            'title',
            'editor',
            'excerpt',
            'trackbacks',
            'custom-fields',
            'comments',
            'revisions',
            'thumbnail',
            'author',
            'page-attributes'
        )
    );
    register_post_type( 'property', $args );
    // register taxonomy
    register_taxonomy('property_category', 'property',
        array(
                'hierarchical'  => true,
                'label'         => 'Category',
                'query_var'     => true,
                'rewrite'       => array(
                'slug'          => 'property-category'
            )
        )
    );
}
add_action( 'init', 'property_init' );

/**cUSTOM FIELDS FOR CUSTOM POST TYPE */
function add_property_meta_box() {
    add_meta_box(
        'property_custom_fields_meta_box',
        'Custom Fields',
        'property_meta_box_callback',
        'property',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'add_property_meta_box' );

function property_meta_box_callback( $post ) {
    // Use nonce for verification
    wp_nonce_field( 'property_meta_box_nonce_action', 'property_meta_box_nonce' );

    // Retrieve existing custom fields (as an array)
    $property_custom_fields = get_post_meta( $post->ID, '_property_custom_fields', true );

    // Initialize custom fields if not an array
    if ( !is_array( $property_custom_fields ) ) {
        $property_custom_fields = array_fill(0, 6, ''); // Initialize with empty values if none exist
    }

    // Display the input fields for the custom fields
    echo '<div id="property-custom-fields-wrapper">';
    
    foreach ( $property_custom_fields as $index => $field ) {
        echo '<p><label for="property_custom_field_' . $index . '">Custom Field ' . ($index + 1) . ': </label>';
        echo '<input type="text" id="property_custom_field_' . $index . '" name="property_custom_fields[]" value="' . esc_attr( $field ) . '" size="25" />';
        echo '<button class="remove-field button">Remove</button></p>';
    }
    
    echo '</div>';

    // Button to add more fields
    echo '<button type="button" id="add-more-fields" class="button">Add More Field</button>';
    
    // JavaScript for dynamic fields
    ?>
    <script type="text/javascript">
        (function($){
            $(document).ready(function() {
                var fieldIndex = <?php echo count($property_custom_fields); ?>;
                
                $('#add-more-fields').on('click', function() {
                    var newField = '<p><label for="property_custom_field_' + fieldIndex + '">Custom Field ' + (fieldIndex + 1) + ': </label>';
                    newField += '<input type="text" id="property_custom_field_' + fieldIndex + '" name="property_custom_fields[]" value="" size="25" />';
                    newField += '<button class="remove-field button">Remove</button></p>';
                    $('#property-custom-fields-wrapper').append(newField);
                    fieldIndex++;
                });

                // Remove field
                $(document).on('click', '.remove-field', function(e) {
                    e.preventDefault();
                    $(this).parent('p').remove();
                });
            });
        })(jQuery);
    </script>
    <?php
}

// Save the custom field values
function save_property_meta_box_data( $post_id ) {
    // Check if nonce is set
    if ( ! isset( $_POST['property_meta_box_nonce'] ) ) {
        return;
    }

    // Verify that the nonce is valid
    if ( ! wp_verify_nonce( $_POST['property_meta_box_nonce'], 'property_meta_box_nonce_action' ) ) {
        return;
    }

    // Debug log for checking post ID and custom fields
    error_log('Saving post ID: ' . $post_id);
    error_log('Custom Fields: ' . print_r($_POST['property_custom_fields'], true));

    // Check if this is an autosave and do nothing
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Save the data (as an array)
    if ( isset( $_POST['property_custom_fields'] ) ) {
        $custom_fields = array_map( 'sanitize_text_field', $_POST['property_custom_fields'] );
        update_post_meta( $post_id, '_property_custom_fields', $custom_fields );
    } else {
        // If no fields are set, delete the meta data
        delete_post_meta( $post_id, '_property_custom_fields' );
    }
}
add_action( 'save_post', 'save_property_meta_box_data' );
/**Removing content text area from pages at wordpress admin panel */
add_action( 'init', 'my_remove_post_type_support', 999 );
function my_remove_post_type_support() {
    remove_post_type_support( 'page', 'editor' );
}

//Newsletter admin mail
function handle_newsletter_subscription() {
    if (isset($_POST['subscribe']) && isset($_POST['ne'])) {
        $subscriber_email = sanitize_email($_POST['ne']);

        // Send email to admin
        $admin_email = 'info@gemstar-realty.com';
        $subject = 'Newsletter Subscription';
        $message = 'A new user has subscribed to the newsletter. Email: ' . $subscriber_email;
        $headers = array('Content-Type: text/html; charset=UTF-8');

        wp_mail($admin_email, $subject, $message, $headers);

        // Optionally, save the subscriber's email to the database
        // You can use wp_insert_post, custom tables, or a plugin like WPForms DB
    }
}
add_action('init', 'handle_newsletter_subscription');

?>