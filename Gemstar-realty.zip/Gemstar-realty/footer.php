	<!-- footer start -->

	<footer class="cmn_fttr">
		<div class="container">
			<div class="cmn_ftr_tp">
				<div class="cmn_ftr_prt wow fadeInDown" data-wow-delay="0.2s">
					<a class="ftr_logo" href="<?php echo home_url();?>">
                        <?php
                            the_custom_logo();
                            if(!has_custom_logo()){
                        ?>
                        <?php
                            }
                        ?>
					</a>
					<p><?php echo get_option('footer_cntnt');?></p>
				</div>
				<div class="cmn_ftr_prt wow fadeInUp" data-wow-delay="0.2s">
					<h4>Contact us</h4>
					<ul class="cmn_ftr_list">
						<li class="cmn_ftr_list_itm">
							<span><i class="fas fa-phone"></i></span>
							<a href="tel:<?php echo get_option('call');?>" class="phn"><?php echo get_option('call');?></a>
						</li>
						<li class="cmn_ftr_list_itm">
							<span><i class="fas fa-envelope"></i></span>
							<a href="mailto:<?php echo get_option('email');?>"><?php echo get_option('email');?></a>
						</li>
					</ul>
				</div>
				<div class="cmn_ftr_prt wow fadeInDown" data-wow-delay="0.2s">
					<h4>Main Links</h4>
                    <?php
                        wp_nav_menu(array(
                        'theme_location' => 'footer-menu',
                        'container' => false,
                        'menu_class' => '',
                        'fallback_cb' => '__return_false',
                        'items_wrap' =>'<ul id="%1$s" class="cmn_ftr_list %2$s">%3$s</ul>',
                        //'depth' => 2,
                        'walker' => new bootstrap_5_wp_nav_menu_walker()
                        ));
                    ?>
				</div>
				<div class="cmn_ftr_prt wow fadeInUp" data-wow-delay="0.2s">
					<h4>Follow Us</h4>
					<ul class="cmn_ftr_list">
						<li class="cmn_ftr_list_itm">
							<span><i class="fab fa-facebook-f"></i></span>
							<a href="<?php echo get_option('facebook');?>" class="phn">Facebook</a>
						</li>
						<!-- <li class="cmn_ftr_list_itm">
							<span><i class="fab fa-linkedin-in"></i></span>
							<a href="<?php //echo get_option('linkedin');?>">Linkedin</a>
						</li> -->
						<!-- <li class="cmn_ftr_list_itm">
							<span><i class="fab fa-twitter"></i></span>
							<a href="<?php //echo get_option('twitter');?>">Twitter</a>
						</li> -->
					</ul>
				</div>
				<div class="cmn_ftr_prt wow fadeInDown" data-wow-delay="0.2s">
					<h4>Subscribe Newsletter</h4>
					<!-- <form>
						<input type="email" class="form-control" placeholder="Enter Your Email">
						<input type="submit" class="cmn_btn" value="subscribe">
					</form> -->
					<?php echo do_shortcode('[newsletter_form form="1"]');?>
				</div>
			</div>
			<div class="cmn_ftr_bttm">
				<div class="cmn_ftr_bttm_flx">
					<div class="cmn_ftr_bttm_lft">
						<p>© <?php echo date('Y');?> All rights Reserved. Design by <a href="https://www.hih7.com/">Hih7 Webtech Pvt Ltd</a></p>
					</div>
					<div class="cmn_ftr_bttm_rght">
						<p><a href="<?php echo get_option('term_condtn');?>">Terms & Conditions</a><a href="<?php echo get_option('privacy');?>">Privacy
								policy</a></p>
					</div>
				</div>
			</div>
		</div>
	</footer>

	<!-- footer end -->
    <?php wp_footer(); ?>

	<!-- Back to top button -->
	<a href="javascript:void(0);" id="backToTop">
		<i class="fa fa-solid fa-arrow-up"></i>
	</a>

	<!-- AOS JS -->
	<script>AOS.init();</script>
	<!-- custom nav style start -->

	<script>
		$(document).ready(function () {
			$('#nav-icon3').click(function () {
				$(this).toggleClass('open');
			});
		});
	</script>
<script>
	function emailValidationHandler(selectors) {
            selectors.forEach(selector => {
                $(selector).on('change', function() {
                    let email = $(this).val();
                    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                        alert('Please enter a valid email address');
                        $(this).focus();
                    }
                });
            });
        }
    
        emailValidationHandler([
            '#email_frm','input[name="email-335"]'
        ]);

		 // Keyup handler for alphabetic fields
		 function alphabeticFieldHandler(selectors) {
            selectors.forEach(selector => {
                $(selector).keyup(function() {
                    let val = $(this).val().replace(/[^a-zA-Z\s]/g, ''); // Remove non-alphabetic, non-space characters
                    if (val.length > 0) {
                        val = val.charAt(0).toUpperCase() + val.slice(1); // Capitalize the first letter
                    }
                    $(this).val(val);
                });
            });
        }
        
        alphabeticFieldHandler([
            'input[name="text-114"]', 'input[name="text-11"]', 'input[name="text-1"]','input[name="text-878"]'
        ]);

		// Set maxlength for inputs
        function setMaxLengthAndValidate(selectors, length) {
    selectors.forEach(selector => {
        $(selector)
            .attr('maxlength', length)
            .on('input', function () {
                // Remove any non-numeric characters
                $(this).val($(this).val().replace(/[^0-9]/g, ''));
            });
    });
}

setMaxLengthAndValidate([
    'input[name="tel-739"]','input[name="tel-850"]'
], 13);

	</script>
	<script>
		$(document).ready(function () {
			$('#propertyTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true,   // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function (event) { // Callback function if tab is switched
					var $tab = $(this);
					var $info = $('#tabInfo');
					var $name = $('span', $info);
					$name.text($tab.text());
					$info.show();
				}
			});
		});
	</script>
</body>

</html>