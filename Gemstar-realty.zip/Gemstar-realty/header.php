<!DOCTYPE HTML>
<html lang="<?php language_attributes();?>">

<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>
        <?php
            bloginfo('name');
            wp_title();
            if(is_front_page()) :
                // echo ' | ';
                // bloginfo('description');
            endif;
        ?>
    </title>
	<meta name="description" content="" />
	<meta name="author" content="admin" />
	<meta name="viewport" content="width=device-width; initial-scale=1.0" />
	<link rel="shortcut icon" href="<?php echo bloginfo('template_url');?>/assets/images/favicon.ico" alt="img" />
	<!-- google font start-->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Aleo:ital,wght@0,100..900;1,100..900&display=swap"
		rel="stylesheet">
	<!-- google font end-->
    <?php wp_head();?>
</head>

<body>
	<!-- preloader start -->

	<section id="pre_Loader">
		<div class="loader">
			<div class="quater i"></div>
			<div class="quater ii"></div>
		</div>
	</section>

	<!-- preloader end -->
	<!-- heder strt -->
	<header id="header_id" class="another_hdr">
		<div class="cus_nav_outr">
			<div class="container">
				<div class="cus_nav_innr">
					<div class="logo_area">
                        <?php $logoimage= get_header_image();?>
						<a href="<?php echo home_url();?>">
							<img class="img-fluid" src="<?php echo $logoimage ;?>" alt="img" />
						</a>
					</div>

					<div class="nav_area">

						<div class="right_nav">
							<div class="navbar-header">
								<nav class="navbar navbar-expand-md">

									<div id="nav-icon3" class="navbar-toggler" type="button" data-bs-toggle="collapse"
										data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
										aria-label="Toggle navigation">
										<span></span>
										<span></span>
										<span></span>
										<span></span>
									</div>

									<div class="collapse navbar-collapse main_nav" id="navbarNav">

                                        <?php
                                            wp_nav_menu(
                                                array(
                                                    'theme_location' => 'header-menu',
                                                    'container' => false,
                                                    'menu_class' => '',
                                                    'fallback_cb' => '__return_false',
                                                    'items_wrap' =>'<ul id="%1$s" class="navbar-nav %2$s">%3$s</ul>',
                                                    //'depth' => 2,
                                                    'walker' => new bootstrap_5_wp_nav_menu_walker()
                                                )
                                            );
                                        ?>
										<!-- <div class="hd_btn">
											<a href="<?php //echo get_option('explore_button');?>" class="cmn_btn"><?php //echo get_option('explore_text');?></a>
										</div> -->
									</div>


								</nav>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</header>
	<!--Header End-->