<?php
/**Template Name: Home */
get_header();
?>
	<!--Bnr Start-->
	<section class="banner_sec">
		<div class="bnr_otr">
			<div class="bnr_img_otr">
				<div class="bnr_pic"><img src="<?php the_field('banner_image1');?>"></div>
				<div class="mb_bnr_pic"><img src="<?php the_field('banner_image2');?>"></div>
			</div>
			<div class="container">
				<div class="bnr_content cmn_bnr_txt text-center">
					<div class="dmnd"><img src="<?php the_field('banner_image3');?>" alt="img"></div>
					<h1 class=""><?php the_field('banner_heading');?></h1>
					<p><?php the_field('banner_content');?></p>
				</div>
			</div>
		</div>
	</section>
	<!--Bnr End-->
	<!-- properties prt start -->
	<section class="prpts_sec">
		<div class="container">
			<div class="prpts_ottr">
				<form class="prpts_frm" role="search" method="get" action="<?php the_permalink();?>">
					<div class="prpts_frm_txt">
						<span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span>
							<div class="cmn_hdr">
								<h6><?php the_field('property_section_heading');?></h6>
							</div>
						<span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span>
					</div>
					<div class="prpts_frm_bxs">
						<div class="form-bx">
							<!-- Property Category: Price -->
							<?php
							$price_parent = get_term_by('slug', 'price', 'property_category');
							?>
							<select name="price" class="form-control">
								<option value=""><?php echo esc_html($price_parent->name); ?></option>
								<?php
								$price_categories = get_terms(array(
									'taxonomy' => 'property_category',
									'parent' => $price_parent->term_id,
									'hide_empty' => true,
								));
								foreach ($price_categories as $price) : ?>
									<option value="<?php echo esc_attr($price->slug); ?>">
										<?php echo esc_html($price->name); ?>
									</option>
									<?php
									// Get child categories of each price category
									$child_prices = get_terms(array(
										'taxonomy' => 'property_category',
										'parent' => $price->term_id,
										'hide_empty' => true,
									));
									foreach ($child_prices as $child) : ?>
										<option value="<?php echo esc_attr($child->slug); ?>">— <?php echo esc_html($child->name); ?></option>
									<?php endforeach; ?>
								<?php endforeach; ?>
							</select>

							<!-- Property Category: Type -->
							<?php
							$type_parent = get_term_by('slug', 'type', 'property_category');
							?>
							<select name="type" class="form-control">
								<option value=""><?php echo esc_html($type_parent->name); ?></option>
								<?php
								$type_categories = get_terms(array(
									'taxonomy' => 'property_category',
									'parent' => $type_parent->term_id,
									'hide_empty' => true,
								));
								foreach ($type_categories as $type) : ?>
									<option value="<?php echo esc_attr($type->slug); ?>">
										<?php echo esc_html($type->name); ?>
									</option>
									<?php
									// Get child categories of each type category
									$child_types = get_terms(array(
										'taxonomy' => 'property_category',
										'parent' => $type->term_id,
										'hide_empty' => true,
									));
									foreach ($child_types as $child) : ?>
										<option value="<?php echo esc_attr($child->slug); ?>">— <?php echo esc_html($child->name); ?></option>
									<?php endforeach; ?>
								<?php endforeach; ?>
							</select>

							<!-- Property Category: Bedrooms -->
							<?php
							$bedrooms_parent = get_term_by('slug', 'bedrooms', 'property_category');
							?>
							<select name="bedrooms" class="form-control">
								<option value=""><?php echo esc_html($bedrooms_parent->name); ?></option>
								<?php
								$bedroom_categories = get_terms(array(
									'taxonomy' => 'property_category',
									'parent' => $bedrooms_parent->term_id,
									'hide_empty' => true,
								));
								foreach ($bedroom_categories as $bedroom) : ?>
									<option value="<?php echo esc_attr($bedroom->slug); ?>">
										<?php echo esc_html($bedroom->name); ?>
									</option>
									<?php
									// Get child categories of each bedroom category
									$child_bedrooms = get_terms(array(
										'taxonomy' => 'property_category',
										'parent' => $bedroom->term_id,
										'hide_empty' => true,
									));
									foreach ($child_bedrooms as $child) : ?>
										<option value="<?php echo esc_attr($child->slug); ?>">— <?php echo esc_html($child->name); ?></option>
									<?php endforeach; ?>
								<?php endforeach; ?>
							</select>
							
							<!-- Property Category: Bathrooms -->
							<?php
							$bathrooms_parent = get_term_by('slug', 'bathrooms', 'property_category');
							?>
							<select name="bathrooms" class="form-control">
								<option value=""><?php echo esc_html($bathrooms_parent->name); ?></option>
								<?php
								$bathroom_categories = get_terms(array(
									'taxonomy' => 'property_category',
									'parent' => $bathrooms_parent->term_id,
									'hide_empty' => true,
								));
								foreach ($bathroom_categories as $bathroom) : ?>
									<option value="<?php echo esc_attr($bathroom->slug); ?>">
										<?php echo esc_html($bathroom->name); ?>
									</option>
									<?php
									// Get child categories of each bathroom category
									$child_bathrooms = get_terms(array(
										'taxonomy' => 'property_category',
										'parent' => $bathroom->term_id,
										'hide_empty' => true,
									));
									foreach ($child_bathrooms as $child) : ?>
										<option value="<?php echo esc_attr($child->slug); ?>">— <?php echo esc_html($child->name); ?></option>
									<?php endforeach; ?>
								<?php endforeach; ?>
							</select>

							<!-- More filters -->

							<select class="form-control">
								<option value="filter">More filters
								</option>
								<option value="filter">More filters
								</option>
								<option value="filter">More filters
								</option>
							</select>

							<!-- Submit Button -->
							<button type="submit" class="cmn_btn prpt_btn">
								<i class="fas fa-search"></i> Search
							</button>
						</div>
					</div>
				</form>
				<!-- Function handling for form -->
				<?php
				if ( isset($_GET['bathrooms']) || isset($_GET['bedrooms']) || isset($_GET['price']) || isset($_GET['type']) ) {
					$tax_query = array('relation' => 'AND');

					// Filter by Bathrooms
					if (!empty($_GET['bathrooms'])) {
						$tax_query[] = array(
							'taxonomy' => 'property_category',
							'field'    => 'slug',
							'terms'    => sanitize_text_field($_GET['bathrooms']),
						);
					}
					// Filter by Bedrooms
					if (!empty($_GET['bedrooms'])) {
						$tax_query[] = array(
							'taxonomy' => 'property_category',
							'field'    => 'slug',
							'terms'    => sanitize_text_field($_GET['bedrooms']),
						);
					}
					// Filter by Price
					if (!empty($_GET['price'])) {
						$tax_query[] = array(
							'taxonomy' => 'property_category',
							'field'    => 'slug',
							'terms'    => sanitize_text_field($_GET['price']),
						);
					}
					// Filter by Type
					if (!empty($_GET['type'])) {
						$tax_query[] = array(
							'taxonomy' => 'property_category',
							'field'    => 'slug',
							'terms'    => sanitize_text_field($_GET['type']),
						);
					}

					// Prepare the query for properties
					$args = array(
						'post_type' => 'property',
						'posts_per_page' => 10,  // Set the number of results per page
						'tax_query' => $tax_query,
					);
					$filtered_properties = new WP_Query($args);

					if ($filtered_properties->have_posts()) {
						echo '<div class="properties-list">';
						while ($filtered_properties->have_posts()) {
							$filtered_properties->the_post();

							// Get the permalink
							$permalink = get_permalink(); // Store the permalink
							
							// Assuming you have custom fields or other logic to define these variables
							$custom_field1 = get_post_meta(get_the_ID(), 'custom_field1', true);
							$custom_field2 = get_post_meta(get_the_ID(), 'custom_field2', true);
							$custom_field3 = get_post_meta(get_the_ID(), 'custom_field3', true);
							$custom_field4 = get_post_meta(get_the_ID(), 'custom_field4', true);
							$custom_field5 = get_post_meta(get_the_ID(), 'custom_field5', true);
							$imagepath = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full'); // Get the featured image

							// Display the property information
							echo '<a href="' . esc_url($permalink) . '" class="sptlght_flx_prt wow fadeInUp" data-wow-delay="0.2s">';
							echo '<div class="sptlght_prt_img srimg">';
							echo '<div class="sptlght_prt_pic srpic">';
							echo '<img src="' . esc_url($imagepath[0]) . '" alt="img">';
							echo '</div>';
							echo '</div>';
							echo '<div class="apt_sl slp">';
							echo '<div class="apt_sl_lft lrp">';
							echo '<div class="cmn_hdr hng">';
							echo '<h6>' . esc_html(get_the_title()) . '</h6>';
							echo '</div>';
							echo '<span class="apt_lft_spn splf">' . esc_html(get_the_content()) . '</span>';
							echo '</div>';
							echo '<div class="apt_sl_rght">';
							echo '<span class="apt_rght_spn rtspn">' . esc_html($custom_field1) . '</span>';
							echo '<span class="apt_rght_spn rtspn">' . esc_html($custom_field2) . '</span>';
							echo '</div>';
							echo '</div>';
							echo '<div class="apt_sl_itms search">';
							echo '<div class="apt_itm_cst ctitm">';
							echo esc_html(get_the_excerpt());
							echo '</div>';
							echo '<div class="apt_itm_nmbrs mb">';
							echo '<span>';
							echo '<img src="' . esc_url(get_bloginfo('template_url') . '/assets/images/bd.png') . '" alt="img">';
							echo esc_html($custom_field3);
							echo '</span>';
							echo '<span>';
							echo '<img src="' . esc_url(get_bloginfo('template_url') . '/assets/images/bth.png') . '" alt="img">';
							echo esc_html($custom_field4);
							echo '</span>';
							echo '<span>';
							echo '<img src="' . esc_url(get_bloginfo('template_url') . '/assets/images/msq.png') . '" alt="img">';
							echo esc_html($custom_field5);
							echo '</span>';
							echo '</div>';
							echo '</div>';
							echo '</a>'; // Closing the link
						}
						echo '</div>'; // Closing properties-list
					} else {
						echo '<p>No properties found matching your criteria.</p>';
					}
					wp_reset_postdata();
				}
				?>
			</div>
		</div>
	</section>
	<!-- properties prt end -->
	<!-- spotlight prt start -->
	<section class="sptlght_sec cmn_pdding">
		<div class="container">
			<div class="sptlght_innr">
				<div class="sptlght_top_txt text-center">
					<div class="cmn_hdr flex">
						<h2 class="justify-content-center"><span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span><?php the_field('spotlight_heading');?><span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span></h2>
						<p><?php the_field('spotlight_content');?></p>
					</div>
				</div>
				<div class="sptlght_flx_bxs">
					<?php
					$wpfeature=array(
						'post_type'=>'property',
						// 'news_category' => 'Mno',
						'orderby'    => 'date',
						'post_status' => 'publish',
						'order'    => 'ASC',
						'posts_per_page' => 2,
					);
					$featurequery=new Wp_Query($wpfeature);
						while($featurequery->have_posts()){
						$featurequery->the_post();
						$imagepath=wp_get_attachment_image_src(get_post_thumbnail_id(),'large');
						/**Show custom fields in front end */
						$property_custom_fields = get_post_meta( get_the_ID(), '_property_custom_fields', true );
						// Set the custom field values dynamically
						$custom_field1 = !empty( $property_custom_fields[0] ) ? esc_html( $property_custom_fields[0] ) : '';
						$custom_field2 = !empty( $property_custom_fields[1] ) ? esc_html( $property_custom_fields[1] ) : '';
						$custom_field3 = !empty( $property_custom_fields[2] ) ? esc_html( $property_custom_fields[2] ) : '';
						$custom_field4 = !empty( $property_custom_fields[3] ) ? esc_html( $property_custom_fields[3] ) : '';
						$custom_field5 = !empty( $property_custom_fields[4] ) ? esc_html( $property_custom_fields[4] ) : '';
						$custom_field6 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[5] ) : '';
					?>
					<?php $url = get_permalink();?>
					<a href="<?php echo $url;?>" class="sptlght_flx_prt wow fadeInUp" data-wow-delay="0.2s">
						<div class="sptlght_prt_img">
							<div class="sptlght_prt_pic">
								<img src="<?php echo $imagepath[0]?>" alt="img">
							</div>
						</div>
						<div class="apt_sl">
							<div class="apt_sl_lft">
								<div class="cmn_hdr">
									<h6><?php the_title();?></h6>
								</div>
								<span class="apt_lft_spn"><?php the_content(); ?></span>
							</div>
							<div class="apt_sl_rght">
								<span class="apt_rght_spn"><?php echo esc_html( $custom_field1 ); ?></span>
								<span class="apt_rght_spn"><?php echo esc_html( $custom_field2 ); ?></span>
							</div>
						</div>
						<div class="apt_sl_itms">
							<div class="apt_itm_cst">
								<?php the_excerpt();?>
							</div>
							<div class="apt_itm_nmbrs">
								<span>
									<img src="<?php echo bloginfo('template_url');?>/assets/images/bd.png" alt="img">
									<?php echo esc_html( $custom_field3 ); ?>
								</span>
								<span>
									<img src="<?php echo bloginfo('template_url');?>/assets/images/bth.png" alt="img">
									<?php echo esc_html( $custom_field4 ); ?>
								</span>
								<span>
									<img src="<?php echo bloginfo('template_url');?>/assets/images/msq.png" alt="img">
									<?php echo esc_html( $custom_field5 ); ?>
								</span>
							</div>
						</div>
					</a>
					<?php
					} 
					wp_reset_postdata(); 
					?>
				</div>
				<div class="sptlght_prt_btn text-center">
					<?php $spot_btn = get_field('spotlight_button');?>
					<a href="<?php echo $spot_btn['url'];?>" class="cmn_btn"><?php echo $spot_btn['title'];?></a>
				</div>
			</div>
		</div>
		<div class="bg_txt">
			<h3><?php the_field('spotlight_heading1');?></h3>
		</div>
	</section>
	<!-- spotlight prt end -->
	<!-- hm about prt start -->
	<section class="hm_abtt_sec cmn_pdding">
		<div class="container">
			<div class="hm_abtt_ottr">
				<div class="hm_abtt_flx wow fadeInDown" data-wow-delay="0.2s">
					<div class="hm_abtt_lft">
						<div class="hm_abtt_lft_imgone"><img src="<?php the_field('about_image1');?>" alt="img"></div>
						<div class="hm_abtt_lft_imgtwo"><img src="<?php the_field('about_image2');?>" alt="img"></div>
					</div>
					<div class="hm_abtt_rght">
						<div class="cmn_hdr flex">
							<h2><span><img src="<?php echo bloginfo('template_url');?>/assets/images/images/ba_dsh.png" alt="img"></span><?php the_field('about_heading1');?><span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span></h2>
							<h2><?php the_field('about_heading2');?></h2>
							<p><?php the_field('about_content');?></p>
						</div>
						<div class="cmn_hdr flex mbl_copy">
							<h2 class="justify-content-center"><span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span><?php the_field('about_heading3');?><span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span></h2>
							<p><?php the_field('about_content');?></p>
						</div>
						<div class="hm_abtt_btn">
							<?php $abt_btn = get_field('about_button');?>
							<a href="<?php echo $abt_btn['url'];?>" class="cmn_btn"><?php echo $abt_btn['title'];?></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<!-- hm about prt end -->
<!-- self compny status start -->
	<section class="slf_cmpny_sec cmn_pdding">
		<div class="container">
			<div class="slf_cmpny_innr">
				<div class="slf_cmpny_flx">
				<?php
                        if( have_rows('self_company_details') ) {
                            while( have_rows('self_company_details') ) {
                                the_row();
                    ?>
                       <div class="slf_cmpny_prt wow fadeInDown" data-wow-delay="0.2s">
						<div class="slf_cmpny_prt_pic">
							<img src="<?php the_sub_field('image');?>" alt="img">
						</div>
						<h6><?php the_sub_field('heading');?></h6>
						<div class="cmn_hdr">
							<p><?php the_sub_field('content');?></p>
						</div>
					</div>
    <?php
        }
      }
    ?>
				</div>
			</div>
		</div>
	</section>
<!-- self compny status end -->
<!-- project place start -->
 <section class="prj_plc_sec">
		<div class="container">
			<div class="prj_plc_ottr">
				<div class="prj_plc_img">
					<img src="<?php the_field('project_place_image');?>" alt="img">
				</div>
				<div class="prj_plc_slp">
					<div class="cmn_hdr wht">
						<h2><?php the_field('project_place_heading');?></h2>
						<p><?php the_field('project_place_content');?>
						</p>
					</div>
					<div class="rd_mr">
					<?php $readmore_button = get_field('project_place_readmore_button');?>
						<a href="<?php echo $readmore_button['url'];?>" class="rd_mr_btn"><?php echo $readmore_button['title'];?></a>
					</div>
				</div>
			</div>
		</div>
	</section>
<!-- project place end -->
<!-- customer slider sec start -->
 <section class="cstmr_sld_sec cmn_pdding">
		<div class="container">
			<div class="cstmr_sld_ottr">
				<div class="cstmr_sld_txt">
					<div class="cmn_hdr flex">
						<h2 class="justify-content-center"><span><img src="<?php the_field('customerssay_left_dash_icon');?>" alt="img"></span><?php the_field('customers_says_heading');?><span><img src="<?php the_field('customerssay_right_dash_icon');?>" alt="img"></span></h2>
					</div>
				</div>
				<div class="cstmr_sld_main">
					<div class="cstmr_main_slider swiper mySwiper2">
						<div class="swiper-wrapper">
						<?php
                        if( have_rows('customers_details') ) {
                            while( have_rows('customers_details') ) {
                                the_row();
                    ?>
                        <div class="swiper-slide">
								<div class="cstmr-swpbx">
									<div class="strs">
										<span><i class="fas fa-star"></i></span>
										<span><i class="fas fa-star"></i></span>
										<span><i class="fas fa-star"></i></span>
										<span><i class="fas fa-star"></i></span>
										<span><i class="fas fa-star"></i></span>
									</div>
									<div class="cmn_hdr">
										<p><?php the_sub_field('comment');?>
										</p>
									</div>
									<div class="nmng">
										<span><img src="<?php the_sub_field('image');?>" alt="img"></span>
										<h6><?php the_sub_field('name');?></h6>
									</div>
								</div>
							</div>
    <?php
        }
      }
    ?>
						</div>
					</div>
					<div class="btn-otr">
						<div class="swiper-button-prev2">
							<i class="fas fa-chevron-left"></i>
						</div>
						<div class="swiper-button-next2">
							<i class="fas fa-chevron-right"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<!-- customer slider sec end -->
<!-- new journey start -->
<section class="new_jour cmn_pdding" style="background: url(<?php echo bloginfo('template_url');?>/assets/images/get_start_im.png) no-repeat;
background-size: 100% 100%;
width: 100%;
height: 100%;">
		<div class="container">
			<div class="new_innr cmn_hdr wht">
				<div class="new_jour_img">
					<img src="<?php the_field('new_journey_image');?>" />
				</div>
				<h2><?php the_field('new_journey_heading');?></h2>
				<p><?php the_field('new_journey_content');?></p>
				<div class="rd_mr">
				<?php $nwjrny_getstarted_button = get_field('new_journey_getstarted_button');?>
					<a href="<?php echo $nwjrny_getstarted_button['url'];?>" class="rd_mr_btn"><?php echo $nwjrny_getstarted_button['title'];?></a>
				</div>
			</div>
		</div>
	</section>
<!-- new journey end -->
<?php
get_footer();
?>