<?php 
/**Template Name: Properties */
get_header();
?>
	<!--Bnr Start-->
	<section class="banner_sec abt_bnr">
		<div class="bnr_otr">
			<div class="bnr_img_otr">
				<div class="bnr_pic"><img src="<?php the_field('banner_image1');?>"></div>
				<div class="mb_bnr_pic"><img src="<?php the_field('banner_image2');?>"></div>
			</div>
			<div class="container">
				<div class="bnr_content cmn_bnr_txt text-center">
					<div class="dmnd"><img src="<?php the_field('banner_image3');?>" alt="img"></div>
					<h1 class=""><?php the_field('banner_heading');?></h1>
				</div>
			</div>
		</div>
	</section>
	<!--Bnr End-->
    	<!-- property list tb start -->
	<section class="prpt_lst_tb_sec cmn_pdding">
		<div class="container">
			<div class="prpt_lst_tb_innr">
				<div id="propertyTab">
					<ul class="resp-tabs-list prpt_resp_tab_ul">
                        <?php
                        if(have_rows('tab_heading')){
                            while(have_rows('tab_heading')){
                                the_row();
                        ?>
						<li class="prpt_resp_tab_grp"><span><img src="<?php the_sub_field('image')?>" alt="img"></span> <?php the_sub_field('heading')?></li>
                        <?php
                            }
                        }
                        ?>
					</ul>
					<div class="resp-tabs-container prpt_tabs_container">
						<div class="prpt_tabs_prt">
							<div class="prpt_tabs_prt_flx">
                                <?php
                                    $category_slug = array('for-sale','for-rent'); // Replace with your actual category slug
                                    $wpfeature = array(
                                        'post_type' => 'property', // Custom post type
                                        'orderby'    => 'date',
                                        'post_status' => 'publish',
                                        // 'order'    => 'ASC',
                                        'posts_per_page'    => 4,
                                        'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                                        'tax_query' => array(
                                            array(
                                                'taxonomy' => 'property_category', // Replace with your custom taxonomy name
                                                'field'    => 'slug',
                                                'terms'    => $category_slug, // The category slug to filter by
                                            ),
                                        ),
                                    );

                                    $featurequery = new WP_Query($wpfeature);
                                    while ($featurequery->have_posts()) {
                                        $featurequery->the_post();
                                        $imagepath = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
                                        $property_custom_fields = get_post_meta( get_the_ID(), '_property_custom_fields', true );
						                // Set the custom field values dynamically
                                        $custom_field1 = !empty( $property_custom_fields[0] ) ? esc_html( $property_custom_fields[0] ) : '';
                                        $custom_field2 = !empty( $property_custom_fields[1] ) ? esc_html( $property_custom_fields[1] ) : '';
                                        $custom_field3 = !empty( $property_custom_fields[2] ) ? esc_html( $property_custom_fields[2] ) : '';
                                        $custom_field4 = !empty( $property_custom_fields[3] ) ? esc_html( $property_custom_fields[3] ) : '';
                                        $custom_field5 = !empty( $property_custom_fields[4] ) ? esc_html( $property_custom_fields[4] ) : '';
                                        $custom_field6 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[5] ) : '';
                                ?>
                                <?php $url = get_permalink();?>
								<a href="<?php echo $url;?>" class="sptlght_flx_prt wow fadeInUp" data-wow-delay="0.2s">
									<div class="sptlght_prt_img">
										<div class="sptlght_prt_pic">
											<img src="<?php echo $imagepath[0]?>" alt="img">
										</div>
									</div>
									<div class="apt_sl">
										<div class="apt_sl_lft">
											<div class="cmn_hdr">
												<h6><?php the_title();?></h6>
											</div>
											<span class="apt_lft_spn"><?php the_content(); ?></span>
										</div>
										<div class="apt_sl_rght">
											<span class="apt_rght_spn"><?php echo esc_html( $custom_field1 ); ?></span>
											<span class="apt_rght_spn"><?php echo esc_html( $custom_field2 ); ?></span>
										</div>
									</div>
									<div class="apt_sl_itms">
										<div class="apt_itm_cst">
											<?php the_excerpt();?>
										</div>
										<div class="apt_itm_nmbrs">
                                            <span>
                                                <img src="<?php echo bloginfo('template_url');?>/assets/images/bd.png" alt="img">
                                                <?php echo esc_html( $custom_field3 ); ?>
                                            </span>
                                            <span>
                                                <img src="<?php echo bloginfo('template_url');?>/assets/images/bth.png" alt="img">
                                                <?php echo esc_html( $custom_field4 ); ?>
                                            </span>
                                            <span>
                                                <img src="<?php echo bloginfo('template_url');?>/assets/images/msq.png" alt="img">
                                                <?php echo esc_html( $custom_field5 ); ?>
                                            </span>
                                        </div>
									</div>
								</a>
                                <?php
                                    }
                                    wp_reset_postdata();
                                ?>
							</div>
						</div>
						<div class="prpt_tabs_prt">
							<div class="prpt_tabs_prt_flx">
                                <?php
                                    $category_slug = array('for-rent','for-sale'); // Replace with your actual category slug
                                    $wpfeature = array(
                                        'post_type' => 'property', // Custom post type
                                        'orderby'    => 'date',
                                        'post_status' => 'publish',
                                        // 'order'    => 'ASC',
                                        'posts_per_page'    => 4,
                                        'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                                        'tax_query' => array(
                                            array(
                                                'taxonomy' => 'property_category', // Replace with your custom taxonomy name
                                                'field'    => 'slug',
                                                'terms'    => $category_slug, // The category slug to filter by
                                            ),
                                        ),
                                    );

                                    $featurequery = new WP_Query($wpfeature);
                                    while ($featurequery->have_posts()) {
                                        $featurequery->the_post();
                                        $imagepath = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
                                        $property_custom_fields = get_post_meta( get_the_ID(), '_property_custom_fields', true );
						                // Set the custom field values dynamically
                                        $custom_field1 = !empty( $property_custom_fields[0] ) ? esc_html( $property_custom_fields[0] ) : '';
                                        $custom_field2 = !empty( $property_custom_fields[1] ) ? esc_html( $property_custom_fields[1] ) : '';
                                        $custom_field3 = !empty( $property_custom_fields[2] ) ? esc_html( $property_custom_fields[2] ) : '';
                                        $custom_field4 = !empty( $property_custom_fields[3] ) ? esc_html( $property_custom_fields[3] ) : '';
                                        $custom_field5 = !empty( $property_custom_fields[4] ) ? esc_html( $property_custom_fields[4] ) : '';
                                        $custom_field6 = !empty( $property_custom_fields[5] ) ? esc_html( $property_custom_fields[5] ) : '';
                                ?>
                                <?php $url = get_permalink();?>
								<a href="<?php echo $url;?>" class="sptlght_flx_prt wow fadeInUp" data-wow-delay="0.2s">
									<div class="sptlght_prt_img">
										<div class="sptlght_prt_pic">
											<img src="<?php echo $imagepath[0]?>" alt="img">
										</div>
									</div>
									<div class="apt_sl">
										<div class="apt_sl_lft">
											<div class="cmn_hdr">
												<h6><?php the_title();?></h6>
											</div>
											<span class="apt_lft_spn"><?php the_content(); ?></span>
										</div>
										<div class="apt_sl_rght">
											<span class="apt_rght_spn"><?php echo esc_html( $custom_field1 ); ?></span>
											<span class="apt_rght_spn"><?php echo esc_html( $custom_field2 ); ?></span>
										</div>
									</div>
									<div class="apt_sl_itms">
										<div class="apt_itm_cst">
											<?php the_excerpt();?>
										</div>
										<div class="apt_itm_nmbrs">
											<span>
                                                <img src="<?php echo bloginfo('template_url');?>/assets/images/bd.png" alt="img">
                                                <?php echo esc_html( $custom_field3 ); ?>
                                            </span>
                                            <span>
                                                <img src="<?php echo bloginfo('template_url');?>/assets/images/bth.png" alt="img">
                                                <?php echo esc_html( $custom_field4 ); ?>
                                            </span>
                                            <span>
                                                <img src="<?php echo bloginfo('template_url');?>/assets/images/msq.png" alt="img">
                                                <?php echo esc_html( $custom_field5 ); ?>
                                            </span>
										</div>
									</div>
								</a>
								<?php
                                    }
                                    wp_reset_postdata();
                                ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- property list tb end -->
    <!-- new journey start -->
	<section class="new_jour cmn_pdding" style="background: url(<?php echo bloginfo('template_url');?>/assets/images/get_start_im.png) no-repeat; background-size: 100% 100%; width: 100%; height: 100%;">
        <div class="container">
            <div class="new_innr cmn_hdr wht">
                <div class="new_jour_img">
                    <img src="<?php the_field('new_journey_image',6);?>" />
                </div>
                <h2><?php the_field('new_journey_heading',6);?></h2>
                <p><?php the_field('new_journey_content',6);?></p>
                <div class="rd_mr">
                <?php $nwjrny_getstarted_button = get_field('new_journey_getstarted_button',6);?>
                    <a href="<?php echo $nwjrny_getstarted_button['url'];?>" class="rd_mr_btn"><?php echo $nwjrny_getstarted_button['title'];?></a>
                </div>
            </div>
        </div>
    </section>
	<!-- new journey end -->
<?php
get_footer();
?>