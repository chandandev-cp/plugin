<?php
//Template Name: Contact page
get_header();
?>
<!--Bnr Start-->
<section class="banner_sec abt_bnr">
		<div class="bnr_otr">
			<div class="bnr_img_otr">
				<div class="bnr_pic"><img src="<?php the_field('banner_image');?>"></div>
				<div class="mb_bnr_pic"><img src="<?php the_field('mobile_banner_image');?>"></div>
			</div>
			<div class="container">
				<div class="bnr_content cmn_bnr_txt text-center">
					<div class="dmnd"><img src="<?php the_field('banner_diamond_image');?>" alt="img"></div>
					<h1 class=""><?php the_field('banner_heading');?></h1>
				</div>
			</div>
		</div>
	</section>
	<!--Bnr End-->
    <!-- get touch start -->
	<section class="gt_tch_sec cmn_pdding">
		<div class="container">
			<div class="gt_tch_innr">
				<div class="gt_tch_flx">
					<div class="gt_tch_lft">
						<div class="cmn_hdr flex">
							<h2>Contact Us <span><img src="<?php echo bloginfo('template_url');?>/assets/images/ba_dsh.png" alt="img"></span></h2>
							<p>
								<?php the_field('get_in_touch_sec_content');?>
							</p>
						</div>
						<div class="gt_tch_lst_otr">
							<ul>
								<li>
									<span><i class="fas fa-phone"></i></span>
									<a href="tel:<?php echo get_option('call');?>">
									<?php echo get_option('call');?>
									</a>
								</li>
								<li>
									<span><i class="fas fa-envelope"></i></span>
									<a href="mailto:<?php echo get_option('email');?>">
									<?php echo get_option('email');?>
									</a>
								</li>
								<li>
									<span><i class="fab fa-facebook-f"></i></span>
									<a href="<?php echo get_option('facebook');?>">
										<?php the_field('get_in_touch_facebook_heading');?>
									</a>
								</li>
								<!-- <li>
									<span><i class="fab fa-linkedin-in"></i></span>
									<a href="<?php //echo get_option('linkedin');?>">
									<?php //the_field('get_in_touch_linkedin_heading');?>
									</a>
								</li> -->
								<!-- <li>
									<span><i class="fab fa-twitter"></i></span>
									<a href="<?php //echo get_option('twitter');?>">
									<?php //the_field('get_in_touch_twitter_heading');?>
									</a>
								</li> -->
							</ul>
							<div class="gt_tch_lft_star">
								<div class="bg_start_pic">
									<img src="<?php echo bloginfo('template_url');?>/assets/images/gt_tch_star.png" alt="img">
								</div>
							</div>
						</div>
					</div>
					<div class="gt_tch_rght">
						<div class="gt_tch_rght_txt">
							<div class="cmn_hdr wht">
								<h2>Get In Touch</h2>
							</div>
							<div class="cmn_hdr">
								<p>Start a new case. Just send us your questions
									or concerns by starting a new case and we will give you the help you need.
								</p>
							</div>
						</div>
						<div class="gt_tch_rght_frm">
							<?php echo do_shortcode('[contact-form-7 id="d157f29" title="contact form"]');?>
						</div>
					</div>
					<div class="bg_txt">
						<h3>Gemstar Realty</h3>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- get touch end -->
	 <!-- contact page map start -->
	<section class="cnt_pg_mp">
		<iframe class="cnt_pg_frame"
			src="<?php the_field('contact_page_map_section');?>"
			width="100%" style="border:0;" allowfullscreen="" loading="lazy"
			referrerpolicy="no-referrer-when-downgrade"></iframe>
	</section>
	<!-- contact page map end -->
	 <!-- new journey start -->

	 <section class="new_jour cmn_pdding" style="background: url(<?php echo bloginfo('template_url');?>/assets/images/get_start_im.png) no-repeat;
background-size: 100% 100%;
width: 100%;
height: 100%;">
        <div class="container">
            <div class="new_innr cmn_hdr wht">
                <div class="new_jour_img">
                    <img src="<?php the_field('new_journey_image',6);?>" />
                </div>
                <h2><?php the_field('new_journey_heading',6);?></h2>
                <p><?php the_field('new_journey_content',6);?></p>
                <div class="rd_mr">
                <?php $nwjrny_getstarted_button = get_field('new_journey_getstarted_button',6);?>
                    <a href="<?php echo $nwjrny_getstarted_button['url'];?>" class="rd_mr_btn"><?php echo $nwjrny_getstarted_button['title'];?></a>
                </div>
            </div>
        </div>
    </section>
	<!-- new journey end -->
<?php
get_footer();
?>
