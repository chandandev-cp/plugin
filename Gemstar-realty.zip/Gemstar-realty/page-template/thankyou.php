<?php
//Template Name: Thankyou page
get_header();
?>
<section class="banner_sec">
		<div class="bnr_otr">
			<div class="bnr_img_otr">
				<div class="bnr_pic"><img src="https://kushalsethia.com/backend/Gemstar_realty/wp-content/uploads/2024/09/thankyou_bnr.png"></div>
				<div class="mb_bnr_pic"><img src="https://kushalsethia.com/backend/Gemstar_realty/wp-content/uploads/2024/09/hm_mbl_bnnr.png"></div>
			</div>
			<div class="container">
				<div class="bnr_content cmn_bnr_txt text-center thankyou_otr">
					<div class="dmnd"><img src="https://kushalsethia.com/backend/Gemstar_realty/wp-content/uploads/2024/09/diamond.png" alt="img"></div>
					<h1 class="">THANK YOU FOR YOUR SUBSCRIPTION</h1>
					<p>For any questions or queries, pls feel free to connect with us</p></br>
					<p>Contact No - <a href="tel:+1 (721) 580-0020"> +1 (721) 580-0020</a></p></br>
					<p>Email id - <a href="mailto:info@gemstar-realty.com"> info@gemstar-realty.com</a></p>
				</div>
			</div>
		</div>
	</section>
<?php
get_footer();
?>