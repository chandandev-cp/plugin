<?php /* Template Name: About page */
get_header();?>
<!--Bnr Start-->
<section class="banner_sec abt_bnr">
		<div class="bnr_otr">
			<div class="bnr_img_otr">
				<div class="bnr_pic"><img src="<?php the_field('banner_image');?>"></div>
				<div class="mb_bnr_pic"><img src="<?php the_field('mbl_banner_image');?>"></div>
			</div>
			<div class="container">
				<div class="bnr_content cmn_bnr_txt text-center">
					<div class="dmnd"><img src="<?php the_field('banner_content_image');?>" alt="img"></div>
					<h1 class=""><?php the_field('banner_heading');?></h1>
				</div>
			</div>
		</div>
	</section>
<!--Bnr End-->
<!-- about prt start -->
<section class="hm_abtt_sec abt_pg_self cmn_pdding">
		<div class="container">
			<div class="hm_abtt_ottr">
				<div class="hm_abtt_flx wow fadeInDown" data-wow-delay="0.2s">
					<div class="hm_abtt_lft">
						<div class="hm_abtt_lft_imgone"><img src="<?php the_field('about_banner_image');?>" alt="img"></div>
					</div>
					<div class="hm_abtt_rght">
						<div class="cmn_hdr flex">
							<h2><span><img src="<?php the_field('about_dashicon_image');?>" alt="img"></span><?php the_field('about_heading');?><span><img
										src="<?php the_field('about_dashicon_image_2');?>" alt="img"></span></h2>
							<h2><?php the_field('gemstar_realty_heading');?></h2>

							<?php the_field('about_content');?>
						</div>
						<div class="cmn_hdr flex mbl_copy">
							<h2 class="justify-content-center"><span><img src="<?php the_field('about_dashicon_mobl_image');?>"
										alt="img"></span><?php the_field('about_mobl_heading');?><span><img src="<?php the_field('about_dashicon_mobl_image_2');?>"
										alt="img"></span></h2>
							<?php the_field('about_content_mobl');?>
						</div>
						<div class="hm_abtt_btn">
							<a href="jvascript:void(0);" class="cmn_btn">read more</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="bg_txt">
			<h3><?php the_field('gemstar_realty_image_heading');?></h3>
		</div>
	</section>
<!-- about prt end -->
<!-- mission and vision start -->
 <section class="prpts_sec bt_prpts_sec cmn_pdding">
		<div class="container">
			<div class="prpts_ottr">
				<div class="prpts_flx_bxs">
				<?php
                        if( have_rows('mission_vission_details') ) {
                            while( have_rows('mission_vission_details') ) {
                                the_row();
                    ?>
                        <div class="prpts_flx_prt wow fadeInUp" data-wow-delay="0.2s"
						style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
						<div class="prpts_flx_prt_innr">
							<div class="prpt_prt_img">
								<div class="prpt_prt_pic">
									<img src="<?php the_sub_field('image1');?>" alt="img">
								</div>
							</div>
							<div class="prpts_flx_txt">
								<div class="prpt_dmnd">
									<img src="<?php the_sub_field('image2');?>" alt="img">
								</div>
								<div class="cmn_hdr">
									<h6><?php the_sub_field('heading');?></h6>
									<p>
									<?php the_sub_field('content');?>
									</p>
								</div>

							</div>
						</div>
					</div>
    <?php
        }
      }
    ?>
					<!-- <div class="prpts_flx_prt wow fadeInUp" data-wow-delay="0.2s"
						style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
						<div class="prpts_flx_prt_innr">
							<div class="prpt_prt_img">
								<div class="prpt_prt_pic">
									<img src="./images/msn.jpg" alt="img">
								</div>
							</div>
							<div class="prpts_flx_txt">
								<div class="prpt_dmnd">
									<img src="./images/prpt_dmnd.png" alt="img">
								</div>
								<div class="cmn_hdr">
									<h6>Our Mission</h6>
									<p>
										Lorem ipsum dolor sit amet,
										consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
										et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.
									</p>
								</div>

							</div>
						</div>
					</div>
					<div class="prpts_flx_prt wow fadeInDown" data-wow-delay="0.2s"
						style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInDown;">
						<div class="prpts_flx_prt_innr">
							<div class="prpt_prt_img">
								<div class="prpt_prt_pic">
									<img src="./images/vsn.jpg" alt="img">
								</div>
							</div>
							<div class="prpts_flx_txt">
								<div class="prpt_dmnd">
									<img src="./images/prpt_dmnd.png" alt="img">
								</div>
								<div class="cmn_hdr">
									<h6>Our Vision</h6>
									<p>
										Lorem ipsum dolor sit amet,
										consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
										et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.
									</p>
								</div>
							</div>
						</div>
					</div> -->
				</div>
			</div>
		</div>
	</section>
<!-- mission and vision end -->
<!-- self compny status start -->
 <section class="slf_cmpny_sec cmn_pdding">
		<div class="container">
			<div class="slf_cmpny_innr">
				<div class="slf_cmpny_flx">
				<?php
                        if( have_rows('self_company_details') ) {
                            while( have_rows('self_company_details') ) {
                                the_row();
                    ?>
                       <div class="slf_cmpny_prt wow fadeInDown" data-wow-delay="0.2s">
						<div class="slf_cmpny_prt_pic">
							<img src="<?php the_sub_field('image');?>" alt="img">
						</div>
						<h6><?php the_sub_field('heading');?></h6>
						<div class="cmn_hdr">
							<p><?php the_sub_field('content');?></p>
						</div>
					</div>
    <?php
        }
      }
    ?>
					<!-- <div class="slf_cmpny_prt wow fadeInDown" data-wow-delay="0.2s">
						<div class="slf_cmpny_prt_pic">
							<img src="./images/diamond.png" alt="img">
						</div>
						<h6>We Believe In Hard
							Working Professionalism</h6>
						<div class="cmn_hdr">
							<p>At Gemstar Realty, diligence and expertise are the pillars that uphold our services. Our
								team is committed to delivering exceptional results, ensuring that every transaction
								is handled with the utmost professionalism. Your investment journey is a serious
								endeavor, & we're here to navigate it
								with a hardworking ethos.</p>
						</div>
					</div>
					<div class="slf_cmpny_prt wow fadeInUp" data-wow-delay="0.2s">
						<div class="slf_cmpny_prt_pic">
							<img src="./images/diamond.png" alt="img">
						</div>
						<h6>Connecting With The
							Client Is Our Starting Point</h6>
						<div class="cmn_hdr">
							<p>Understanding your unique real estate desires and concerns is our priority.
								We believe in fostering a personalized connection with each client, which
								enables us to tailor our services to
								meet your specific needs. At Gemstar Realty, your real estate voyage begins
								with a meaningful conversation.</p>
						</div>
					</div>
					<div class="slf_cmpny_prt wow fadeInDown" data-wow-delay="0.2s">
						<div class="slf_cmpny_prt_pic">
							<img src="./images/diamond.png" alt="img">
						</div>
						<h6>A Creative And
							Innovative Agency</h6>
						<div class="cmn_hdr">
							<p>Your trust is our most valued asset.
								At Gemstar Realty, we have a proven
								track record of satisfied homeowners & investors. Our transparent practices,
								coupled with a dedication to ethical
								service, ensure that you can confidently embark on your real estate journey with
								us by your side.</p>
						</div>
					</div>
					<div class="slf_cmpny_prt wow fadeInUp" data-wow-delay="0.2s">
						<div class="slf_cmpny_prt_pic">
							<img src="./images/diamond.png" alt="img">
						</div>
						<h6>Trust Us - You're
							In Good Hands</h6>
						<div class="cmn_hdr">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
								incid idunt ut labore ellt dolore magna
								the alora the tolda on tolda voubal fouter.</p>
						</div>
					</div> -->
				</div>
			</div>
		</div>
	</section>
<!-- self compny status end -->
 <!-- new journey start -->

 <section class="new_jour cmn_pdding" style="background: url(<?php echo bloginfo('template_url');?>/assets/images/get_start_im.png) no-repeat;
background-size: 100% 100%;
width: 100%;
height: 100%;">
        <div class="container">
            <div class="new_innr cmn_hdr wht">
                <div class="new_jour_img">
                    <img src="<?php the_field('new_journey_image',6);?>" />
                </div>
                <h2><?php the_field('new_journey_heading',6);?></h2>
                <p><?php the_field('new_journey_content',6);?></p>
                <div class="rd_mr">
                <?php $nwjrny_getstarted_button = get_field('new_journey_getstarted_button',6);?>
                    <a href="<?php echo $nwjrny_getstarted_button['url'];?>" class="rd_mr_btn"><?php echo $nwjrny_getstarted_button['title'];?></a>
                </div>
            </div>
        </div>
    </section>
	<!-- new journey end -->
<?php get_footer();?>