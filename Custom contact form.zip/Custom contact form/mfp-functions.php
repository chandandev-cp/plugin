<?php
/*
 * Add my new menu to the Admin Control Panel
 */
// Hook the 'admin_menu' action hook, run the function named 'mfp_Add_My_Admin_Link()'
// Add a new top-level menu item to the WordPress admin menu

function custom_contact_form(){

	global $wpdb; // Global WordPress database object
        // Flag for form submission success
        $form_submitted = false;
    // Handle form submission
    if (isset($_POST['submit_contact_form'])) {
        // Sanitize form data
        $name    = sanitize_text_field($_POST['name']);
        $email   = sanitize_email($_POST['email']);
        $phone   = sanitize_text_field($_POST['phone']);
        $address = sanitize_text_field($_POST['address']);
        $degree=  sanitize_text_field($_POST['degree']);
        $message = sanitize_textarea_field($_POST['message']);

        // Insert data into the custom database table
        $table_name = $wpdb->prefix . 'custom_contact_submission_form'; // Your custom table
		// $submissions= $wpdb->get_results('SELECT * FROM $table_name', ARRAY_A);
        $wpdb->insert(
            $table_name,
            array(
                'name'    => $name,
                'email'   => $email,
                'phone'   => $phone,
                'address' => $address,
                'degree' => $degree,
                'message' => $message
				
			),
			array(
                '%s', // name as string
                '%s', // email as string
                '%s', // message as string
                '%s',  // timestamp as string
				'%s',  // timestamp as string
                '%s'
            )
        );

        // Send email to admin
        $admin_email = get_option('admin_email'); // Admin email (retrieved from WordPress settings)
        $subject_admin = 'New Contact Form Submission';
        $body_admin = "A new contact form submission has been received:\n\n";
        $body_admin .= "Name: $name\nEmail: $email\nPhone: $phone\nAddress: $address\nMessage: $message\n";
        $headers_admin = array('Content-Type: text/plain; charset=UTF-8');

        wp_mail($admin_email, $subject_admin, $body_admin, $headers_admin);

        // Send confirmation email to the user
        $subject_user = 'Thank you for contacting us!';
        $body_user = "Hi $name,\n\n";
        $body_user .= "Thank you for getting in touch. We have received your message:\n\n";
        $body_user .= "Name: $name\nEmail: $email\nPhone: $phone\nAddress: $address\nMessage: $message\n\n";
        $body_user .= "We will get back to you as soon as possible.\n\nBest regards,\nYour Company Name";
        $headers_user = array('Content-Type: text/plain; charset=UTF-8');

        wp_mail($email, $subject_user, $body_user, $headers_user);
       // Set the flag to true for showing the thank-you message
       $form_submitted = true;
    }

    // Display the form or the thank-you message
    ob_start();
    if ($form_submitted) {
        // Display thank-you message
        echo '<p>Thank you for your submission!</p>';
    } else {
        // Display the form
        ?>
     <div class="contact-form-container">
    <h2>Contact Us</h2>
    <form action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="POST">
      <div class="form-group">
        <label for="name">Your Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" required>
      </div>
      <div class="form-group">
        <label for="email">Your Email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
      </div>
      <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
      </div>
      <div class="form-group">
        <label for="address">Address</label>
        <input type="text" id="address" name="address" placeholder="Enter your address" required>
      </div>
      <div class="form-group">
        <label for="degree">Degree</label>
        <select id="degree" name="degree" required>
          <option value="" disabled selected>Select your degree</option>
          <option value="bachelor">Bachelor's</option>
          <option value="master">Master's</option>
          <option value="phd">Ph.D.</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div class="form-group">
        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5" placeholder="Write your message" required></textarea>
      </div>
      <button type="submit" name="submit_contact_form" class="btn-submit">Submit</button>
    </form>
  </div>
<style>
    /* Reset some default styles */
/* Reset default styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}


.contact-form-container {
  background: #ffffff;
  padding: 25px 30px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  text-align: center; /* Align content in the center */
}

.contact-form-container h2 {
  margin-bottom: 20px;
  font-size: 24px;
  text-align: center;
  color: #333333;
}

.form-group {
  margin-bottom: 15px;
  text-align: left; /* Align labels and inputs */
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #555555;
}

.form-group input,
.form-group textarea,
.form-group select {
  width: 100%;
  padding: 10px;
  border: 1px solid #cccccc;
  border-radius: 5px;
  font-size: 14px;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 3px rgba(0, 123, 255, 0.25);
}

.btn-submit {
  background-color: #007bff;
  color: #ffffff;
  border: none;
  padding: 10px 15px;
  font-size: 16px;
  border-radius: 5px;
  cursor: pointer;
  width: 100%;
  transition: background-color 0.3s ease;
}

.btn-submit:hover {
  background-color: #0056b3;
}

</style>



        <?php
    }
    return ob_get_clean();
}
add_shortcode('custom_contact_form', 'custom_contact_form');
add_action('init', 'custom_contact_form');
?>


<!-- display in admin page -->
<?php
function custom_contact_form_menu() {
    add_menu_page(
        'Contact Form Submissions',
        'Contact Form',
        'manage_options',
        'custom_contact_form',
        'custom_contact_form_page'
    );
}
add_action('admin_menu', 'custom_contact_form_menu');

// Callback function to display the custom admin page

function custom_contact_form_page() {
    global $wpdb;


    // Check if a delete action is triggered
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['submission_id'])) {
        $submission_id = intval($_GET['submission_id']);

        // Delete the submission from the database
        $table_name = $wpdb->prefix . 'custom_contact_submission_form';
        $wpdb->delete($table_name, array('id' => $submission_id));

        // Optionally, you can redirect back to the submissions page after deletion
       ?>
        <script>
            window.location.href = "<?php echo admin_url('admin.php?page=custom_contact_form'); ?>";
        </script>
        <?php
        exit();
    }
    // Check if an edit action is triggered
    if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['submission_id'])) {
        $submission_id = intval($_GET['submission_id']);

        // Retrieve the submission details from the database based on the submission ID
        $table_name = $wpdb->prefix . 'custom_contact_submission_form';
        $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $submission_id), ARRAY_A);

        // Display a form for editing the submission
        ?>
        <div class="wrap">
            <h1>Edit Contact Form Submission</h1>
                <div class="cntct_form">
                    <form method="post" action="">
                        <!-- Display form fields with current values -->
                        <label for="name">Name:</label>
                        <input type="text" name="name" value="<?php echo esc_attr($submission['name']); ?>" required>

                        <label for="email">Email:</label>
                        <input type="email" name="email" value="<?php echo esc_attr($submission['email']); ?>" required>

                        <label for="phone">Phone:</label>
                        <input type="text" name="phone" value="<?php echo esc_attr($submission['phone']); ?>" required>

                        <label for="address">Address:</label>
                        <input type="text" name="address" value="<?php echo esc_attr($submission['address']); ?>" required>
                        
                        <label for="degree">Degree:</label>
                        <select name="degree" style="height:auto;"  required>
                            <option value="">Select</option>
                            <option value="<?php echo esc_attr($submission['degree']); ?>">BA</option>
                            <option value="<?php echo esc_attr($submission['degree']); ?>">BCA</option>
                            <option value="<?php echo esc_attr($submission['degree']); ?>">BSC</option>                
                        </select>
                        <label for="message">Message:</label>
                        <textarea name="message" required><?php echo esc_textarea($submission['message']); ?></textarea>

                        <!-- Include the submission ID for updating the correct row -->
                        <input type="hidden" name="submission_id" value="<?php echo esc_attr($submission_id); ?>">

                        <input type="submit" name="update_submission" value="Update Submission">
                    </form>
                </div>
        </div>
        <?php

        // Check if the form is submitted for updating
        if (isset($_POST['update_submission'])) {
            // Update the submission in the database
            $updated_submission = array(
                'name'    => sanitize_text_field($_POST['name']),
                'email'   => sanitize_email($_POST['email']),
                'phone'   => sanitize_text_field($_POST['phone']),
                'address' => sanitize_text_field($_POST['address']),
                'degree' => sanitize_text_field($_POST['degree']),
                
                'message' => sanitize_textarea_field($_POST['message']),
            );

            $wpdb->update($table_name, $updated_submission, array('id' => $submission_id));

            // Optionally, redirect back to the submissions page after updating
            ?>
        <script>
            window.location.href = "<?php echo admin_url('admin.php?page=custom_contact_form'); ?>";
        </script>
        <?php
            exit();
        }

    } else {
        // Retrieve form submissions from the database
        $table_name = $wpdb->prefix . 'custom_contact_submission_form';
        $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
        ?>

        <div class="wrap">
            <h1>Contact Form Submissions</h1>
             This is Shortcode [custom_contact_form] add any pages or posts.<br>
            <?php //echo do_shortcode('[custom_contact_form]');?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Degree</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                  
                    foreach ($submissions as $submission) : ?>
                        <tr>
                            <td> <?php echo esc_html($submission['id']); ?></td>
                            <td><?php echo esc_html($submission['name']); ?></td>
                            <td><?php echo esc_html($submission['email']); ?></td>
                            <td><?php echo esc_html($submission['phone']); ?></td>
                            <td><?php echo esc_html($submission['address']); ?></td>
                            <td><?php echo esc_html($submission['degree']); ?></td>
                            <td><?php echo esc_html($submission['message']); ?></td>
                            <td><?php echo date('d/m/Y g:i a'); ?></td>
                            <td>
                                <!-- Add an edit link with the submission ID -->
                                <!-- <a href="<?php //echo esc_url(admin_url('admin.php?page=custom_contact_form&action=edit&submission_id=' . $submission['id'])); ?>">Edit</a> -->
                                <!-- Add a delete link with the submission ID -->
                                <a href="<?php echo esc_url(admin_url('admin.php?page=custom_contact_form&action=delete&submission_id=' . $submission['id'])); ?>" onclick="return confirm('Are you sure you want to delete this submission?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php
    }
}

?>