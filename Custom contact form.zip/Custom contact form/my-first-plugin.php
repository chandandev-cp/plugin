<?php
/*
Plugin Name: Custom Contact Form
Description: This is my first plugin! It makes a new admin menu link!
Author: Chandan Patra
Version: 1.0
*/
require_once plugin_dir_path(__FILE__) . '/mfp-functions.php';
// Hook for plugin activation
register_activation_hook(__FILE__, 'create_plugin_database_table');

function create_plugin_database_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_contact_submission_form'; // Define your table name
    $charset_collate = $wpdb->get_charset_collate();

    // SQL statement for creating the table
    $sql = "CREATE TABLE $table_name (
        id mediumint(20) NOT NULL AUTO_INCREMENT,
        name varchar(200) NOT NULL,
        email varchar(150) NOT NULL,
        phone bigint(20) NOT NULL,	
        address varchar(250) NOT NULL,
        message varchar(250) NOT NULL,
        degree varchar(250) NOT NULL, 
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Include the file needed to run dbDelta
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Hook for plugin uninstallation
register_uninstall_hook(__FILE__, 'delete_plugin_database_table');

function delete_plugin_database_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_contact_submission_form'; // Define your table name

    // SQL statement for dropping the table
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql); // Execute the query
}